
# Paquete de Snippets Inseguros (JS y C#)

Este paquete incluye ejemplos **intencionalmente inseguros** para uso educativo en la Sesión 5 (Ética, seguridad y responsabilidad).
**No** deben usarse en producción. Cada archivo contiene un comentario inicial que describe:
- Riesgo principal
- Por qué es peligroso
- Pistas de mitigación (líneas guía)
